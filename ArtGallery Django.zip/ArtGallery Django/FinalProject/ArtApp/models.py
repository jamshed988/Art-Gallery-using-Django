from django.db import models
from django.contrib.auth.models import User


class Artwork(models.Model):
    ArtworkName = models.CharField(max_length=255)
    ArtworkLocation = models.CharField(max_length=255)
    ArtworkMedium = models.CharField(max_length=255)
    ArtworkPrice = models.DecimalField(max_digits=10, decimal_places=2)
    ArtworkRarity = models.CharField(max_length=255)
    ArtworkSize = models.CharField(max_length=255)
    ArtworkWaysToBuy = models.CharField(max_length=255)
    ArtworkYear = models.IntegerField()
    ArtworkLogo = models.ImageField(upload_to="artwork_logos/", blank=True, null=True)
    ArtworkPrice = models.DecimalField(max_digits=10, decimal_places=2)  # Add this line


    def __str__(self):
        return self.ArtworkName


class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    artwork = models.ForeignKey(Artwork, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def total_price(self):
        return self.artwork.ArtworkPrice * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.artwork.ArtworkName} for {self.user.username}"