from django.urls import path
from . import views

app_name = "ArtApp"

urlpatterns = [
    path("", views.register, name="register"),
    path("login/", views.login_, name="login"),
    path("artwork/", views.artwork_list, name="artwork_list"),
    path("form/", views.artwork_form, name="artwork_form"),
    path("form/<int:artwork_id>/", views.artwork_form, name="artwork_edit"),
    path("artwork/<int:artwork_id>/delete/", views.artwork_delete, name="artwork_delete"),
    path("logout/", views.logout_view, name="logout"),
    path("users/", views.user_list, name="user_list"),
    path("user/form/", views.user_form, name="user_form"),
    path("user/form/<int:user_id>/", views.user_form, name="user_edit"),
    path("user/<int:user_id>/delete/", views.user_delete, name="user_delete"),
    path("add_to_cart/<int:artwork_id>/", views.add_to_cart, name="add_to_cart"),
    path("view_cart/", views.view_cart, name="view_cart"),
    path("update_cart/<int:item_id>/", views.update_cart, name="update_cart"),
    path("customer_artwork/", views.customer_artwork_list, name="customer_artwork_list"),
    path("customer_add_to_cart/<int:artwork_id>/", views.customer_add_to_cart, name="customer_add_to_cart"),


]



