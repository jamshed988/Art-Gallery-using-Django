from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .models import Artwork , CartItem
from .forms import ArtworkForm
from django.contrib.auth import logout
from .forms import UserForm  # Import the UserForm
from django.contrib.auth.hashers import make_password

def update_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, user=request.user)

    if request.method == "POST":
        action = request.POST.get("action")

        if action == "update":
            quantity = int(request.POST.get("quantity"))
            cart_item.quantity = quantity
            cart_item.save()

        elif action == "remove":
            cart_item.delete()

    return redirect("ArtApp:view_cart")

def view_cart(request):
    user = request.user
    cart_items = CartItem.objects.filter(user=user)
    total_price = sum(item.artwork.ArtworkPrice * item.quantity for item in cart_items)

    return render(request, "ArtApp/cart.html", {"cart_items": cart_items, "total_price": total_price})

def add_to_cart(request, artwork_id):
    artwork = get_object_or_404(Artwork, id=artwork_id)
    user = request.user

    # Check if the item is already in the cart for the user
    cart_item, created = CartItem.objects.get_or_create(user=user, artwork=artwork)

    # If the item is already in the cart, increase the quantity
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    return redirect("ArtApp:artwork_list")


def customer_add_to_cart(request, artwork_id):
    artwork = get_object_or_404(Artwork, id=artwork_id)
    user = request.user

    # Check if the item is already in the cart for the user
    cart_item, created = CartItem.objects.get_or_create(user=user, artwork=artwork)

    # If the item is already in the cart, increase the quantity
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    return redirect("ArtApp:customer_artwork_list")

def user_list(request):
    users = User.objects.all()
    return render(request, "ArtApp/users.html", {"users": users})

def user_form(request, user_id=None):
    if user_id:
        user = get_object_or_404(User, id=user_id)
    else:
        user = User()

    if request.method == "POST":
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            # Check if the password field is not empty
            if form.cleaned_data['password']:
                # Use make_password to hash the password
                user.password = make_password(form.cleaned_data['password'])
            form.save()
            return redirect("ArtApp:user_list")
    else:
        form = UserForm(instance=user)

    return render(request, "ArtApp/user_form.html", {"form": form})
def user_delete(request, user_id):
    user = get_object_or_404(User, id=user_id)
    user.delete()
    return redirect("ArtApp:user_list")


def logout_view(request):
    logout(request)
    return redirect("ArtApp:register")


def artwork(request):
    return render(request,"ArtApp/artwork.html")


def artwork_list(request):
    artworks = Artwork.objects.all()
    return render(request, "ArtApp/artwork.html", {"artworks": artworks})

def customer_artwork_list(request):
    artworks = Artwork.objects.all()
    return render(request, "ArtApp/customer_artwork.html", {"artworks": artworks})

def artwork_form(request, artwork_id=None):
    if artwork_id:
        artwork = get_object_or_404(Artwork, id=artwork_id)
    else:
        artwork = Artwork()

    if request.method == "POST":
        form = ArtworkForm(request.POST, request.FILES, instance=artwork)
        if form.is_valid():
            form.save()
            return redirect("ArtApp:artwork_list")
    else:
        form = ArtworkForm(instance=artwork)

    return render(request, "ArtApp/form.html", {"form": form})

def artwork_delete(request, artwork_id):
    artwork = get_object_or_404(Artwork, id=artwork_id)
    artwork.delete()
    return redirect("ArtApp:artwork_list")


def form(request):
    return render(request,"ArtApp/form.html")


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        # Check if the username or email already exists
        if User.objects.filter(username=username).exists() or User.objects.filter(email=email).exists():
            return redirect('ArtApp:register')

        # Create a new user
        user = User.objects.create_user(username, email, password)
        user.save()

        return redirect('ArtApp:login')  # Redirect to the login page

    return render(request, "ArtApp/register.html")

def login_(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            # Log in the user
            login(request, user)

            if user.is_superuser:
                return redirect('ArtApp:artwork_list')
            else:
                return redirect('ArtApp:customer_artwork_list')

    return render(request, "ArtApp/login.html")





